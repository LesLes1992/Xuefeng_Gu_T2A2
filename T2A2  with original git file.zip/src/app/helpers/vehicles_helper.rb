module VehiclesHelper
end
