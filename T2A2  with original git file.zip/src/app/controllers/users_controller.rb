class UsersController < ApplicationController
  def changerole
  end
end
